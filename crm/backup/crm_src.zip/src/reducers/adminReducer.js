import { ADMIN_LOGIN } from "../actions/types";
import AdminLogin from "../Login/components/AdminLogin";
const adminReducer = (state={},action)=>{
    switch(action.type){
        case ADMIN_LOGIN : return {...state,AdminLoginInfo:action.payload}
        default : return state;
    }
    
}
export default adminReducer;