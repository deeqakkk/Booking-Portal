import React from 'react';
import { useSelector } from 'react-redux';

const HomePage = () =>{
    return(
        <>
            HOME PAGE
        </>
    )
}

export default HomePage;