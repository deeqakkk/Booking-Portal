import {ADMIN_LOGIN} from './types';
export const admin_login = (admin) =>({
    type:ADMIN_LOGIN,
    payload:admin
})