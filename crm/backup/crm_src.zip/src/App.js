import { Route, Switch } from "react-router-dom";
import { BrowserRouter as Router } from "react-router-dom";
import AdminLogin from "./Login/components/AdminLogin";
import Home from './Home/home';
import "./App.css";

function App() {
  return (
    <Router>
      <Switch>
        <Route path="/" exact component={AdminLogin}></Route>
        <Route path = "/home" exact component={Home}></Route>
      </Switch>
    </Router>
  );
}

export default App;
