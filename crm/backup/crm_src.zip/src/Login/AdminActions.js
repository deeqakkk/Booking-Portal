import axios from "axios";

export const Login = async (values) => {
  console.log("in action");
  console.log(values.password);
  console.log(values.email);
  const admin = await axios.post("http://localhost:3002/api/admin/signin", {
    email: values.email,
    password: values.password,
  });
  return admin.data;
};
