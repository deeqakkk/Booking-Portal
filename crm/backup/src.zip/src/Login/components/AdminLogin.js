import React, { useState } from "react";
import "./AdminLogin.css";
import { Login } from "../AdminActions";
import MyButton from "../../utilities/Button";

const AdminLogin = () => {
  const [userRegistration, setUserRegistration] = useState({
    username: "",
    password: "",
  });

  const LoginUser = async () => {
    try {
      const response = await Login({
        email: userRegistration.username,
        password: userRegistration.password,
      });
      console.log(response);
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <>
      <div className="LoginRegisterModalLogoContainer">
        <div className="LoginRegisterModalLogoText">Fly0kart.com</div>
        <div className="logoImage">
          {/*<img src={flyokartLogo} alt="logo" className="logoSvg"></img>*/}
        </div>
      </div>
      <div className="signIn_wrapper">
        <div className="box_wrapper">
          <div className="signIn_text">Sign In</div>
          <form className="form_wrapper">
            <input
              type="text"
              autoComplete="none"
              placeholder=" Enter your Email"
              value={userRegistration.username}
              onChange={(e) => {
                setUserRegistration({ username: e.target.vlaue });
              }}
              name="username"
              id="username"
              className="input"
            />
          </form>
          <form className="form_wrapper">
            <input
              type="password"
              autoComplete="none"
              placeholder="  *Password"
              value={userRegistration.password}
              onChange={(e) => {
                setUserRegistration({ password: e.target.vlaue });
              }}
              name="password"
              id="password"
              className="input"
            />
          </form>
          <div className="adminLoginBtn">
            <MyButton
              type="default"
              label="Login"
              padding=" 6px 50px 6px 50px"
              fontsize="28px"
              runAction={() => {
                LoginUser();
              }}
            />
          </div>
        </div>
      </div>
    </>
  );
};

export default AdminLogin;
